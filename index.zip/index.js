exports.handler = () => {
  return {
    statusCode: "200",
    body: "The time in Los Angeles is: ",
  };
};
