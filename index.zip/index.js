exports.handler = (event, context, callback) => {
  return {
    statusCode: "200",
    body: "The time in Los Angeles is: ",
  };
};
